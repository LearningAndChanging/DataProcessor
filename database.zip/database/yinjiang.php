<!DOCTYPE html>
	<head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <title>银浆组数据库</title>
        <link rel="stylesheet" type="text/css" href="./css/yinjiang.css" />
        <link rel="stylesheet" type="text/css" href="./css/style1.css" />
		

		
    </head>
    <body>

		
		<div class="container">
			<header>
                <h1>银浆组数据库</h1>
                <h2>数据上传与程序下载页面（在线修改账号密码均为yinjiang）</h2>
			</header>
                <div class="container2">
                <div class="container_buttons">
                <p>实验数据上传</p>
                <div class="container_buttons_">
                    <div class="container_buttons3">
                    <p>
						银浆组数据记录<span>&nbsp;&nbsp;</span>
                        <a href="./uploads/cell/yinjiangupload.html" class="a_demo_one">
                            上传
                        </a>&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="../php/index.php" class="a_demo_one">
                            在线修改
                        </a>
                    </p>
                    </div>
                </div>
                <p>测试数据处理</p>
                <div class="container_buttons_">
                    <div class="container_buttons2">
                    <p>
						
                        <a href="./uploads/IVUpload/IVCurve.php" class="a_demo_one">
                            IV数据处理
                        </a>
                    </p>
                    </div>
                    
                    <div class="container_buttons2">
					<p>
                        
						<a href="./uploads/YJUpload/YJ.php" class="a_demo_one">
                            银浆流变数据处理
                        </a>
                    </p>
                    </div>
                    
                    <div class="container_buttons2">
					<p>
                       
						<a href="./uploads/YJXUpload/YJX.php" class="a_demo_one">
                            有机相流变数据处理
                        </a>
                    </p>
                    </div> 
                </div>    
                <div class="container_buttons_">
                    <div class="container_buttons2">
                    <p>
						
                        <a href="./uploads/QEUpload/QE.php" class="a_demo_one">
                            量子效率数据处理
                        </a>
					</p>
                    </div>
                    <div class="container_buttons2">
					<p>	
                        
						<a href="" class="a_demo_one1">
                            备用
                        </a>
                    </p>
                    </div>
                    <div class="container_buttons2">
					<p>
                        
						<a href="" class="a_demo_one1">
                            备用
                        </a>
                    </p>
                    </div>
                </div>    
                <div class="container_buttons_">
                    <div class="container_buttons2">
                    <p>
						
                        <a href="" class="a_demo_one1">
                            备用
                        </a>
					</p>
                    </div>
                    <div class="container_buttons2">
					<p>	
                        
						<a href="" class="a_demo_one1">
                            备用
                        </a>
                    </p>
                    </div>
                    <div class="container_buttons2">
					<p>
                        
						<a href="" class="a_demo_one1">
                            备用
                        </a>
                    </p>
                    </div>
                </div>    
                </div>
                
			<div class="container_buttons">
                <p>汇总文件下载</p>
                <div class="container_buttons_">
                    <div class="container_buttons3">
                    <p>
                        <a href="./downloads/汇总.xls" class="a_demo_one">
                            IV曲线汇总数据下载
                        </a>
                    </p>
                    </div>
                </div>  
                <p>作图工具下载</p>                
                <div class="container_buttons_">
                    <div class="container_buttons3">
                    <p>
                        <a href="./downloads/IVCurveDrawer v1.5.exe" class="a_demo_one">
                            IV曲线作图工具下载
                        </a>&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="./downloads/IVCurveDrawer v1.5使用说明.txt" class="a_demo_one">
                            IV曲线作图工具使用说明
                        </a>
                    </p>
                    </div>    
                </div>
                <div class="container_buttons_">
                    <div class="container_buttons3">
                    <p>
                        <a href="./downloads/RheologyData v1.1.exe" class="a_demo_one">
                            流变曲线作图工具下载
                        </a>&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="./downloads/RheologyData v1.1使用说明.txt" class="a_demo_one">
                            流变曲线作图工具使用说明
                        </a>
                    </p>
                    </div>    
                </div>
                <p>银浆组公用ftp地址为ftp://219.223.194.196</p>
                <p>账号SAM，密码yinjianggroup，欢迎使用！</p>
            </div>  
        </div>
		
    </body>
</html>