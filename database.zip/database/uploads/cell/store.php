<?php
    $output = shell_exec("store.py");
?>